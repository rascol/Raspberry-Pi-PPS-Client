var searchData=
[
  ['raw_5ferror_5fdecay',['RAW_ERROR_DECAY',['../d4/d6a/pps-client_8h.html#ac9c3f27094347ffa09eeb295b335d95f',1,'pps-client.h']]],
  ['raw_5ferror_5fzero',['RAW_ERROR_ZERO',['../d4/d6a/pps-client_8h.html#a6a1c27e0e0aee3b4aa8e7cbaa8a11e42',1,'pps-client.h']]]
];
