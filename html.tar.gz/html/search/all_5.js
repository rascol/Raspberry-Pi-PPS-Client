var searchData=
[
  ['five_5fminutes',['FIVE_MINUTES',['../d4/d6a/pps-client_8h.html#ad99448f6c9d49583872a6912f333c90b',1,'pps-client.h']]],
  ['freeserialthread',['freeSerialThread',['../df/d28/pps-serial_8cpp.html#a5f4271a6bb9ed778df76908d570a0660',1,'pps-serial.cpp']]],
  ['freesntpthreads',['freeSNTPThreads',['../dc/d4f/pps-sntp_8cpp.html#a05a786e283f51c4aea4de852b7292bb9',1,'pps-sntp.cpp']]],
  ['freqdiff_5fintrvl',['FREQDIFF_INTRVL',['../d4/d6a/pps-client_8h.html#a3579917ba71dd1c384ef8aa5078154b6',1,'pps-client.h']]],
  ['freqoffset',['freqOffset',['../dc/d1d/struct_g.html#ae59f64b56a6a05c940727e937ce449a0',1,'G']]]
];
