var searchData=
[
  ['addr_5flen',['ADDR_LEN',['../dc/d4f/pps-sntp_8cpp.html#ab07a50f0a8c691175d820b5a439e318a',1,'pps-sntp.cpp']]],
  ['adjtimex_5fscale',['ADJTIMEX_SCALE',['../d4/d6a/pps-client_8h.html#a44aba469a6e7345acba7835c5e1afe32',1,'pps-client.h']]],
  ['alert_5fpps_5flost',['ALERT_PPS_LOST',['../d4/d6a/pps-client_8h.html#a072348aa6dbb8104ed1db6af93e165a4',1,'pps-client.h']]]
];
