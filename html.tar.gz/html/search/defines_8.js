var searchData=
[
  ['logbuf_5fsz',['LOGBUF_SZ',['../d4/d6a/pps-client_8h.html#a8117db581bdacd2cd92cd56813fc6592',1,'pps-client.h']]],
  ['low',['LOW',['../d4/d6a/pps-client_8h.html#ab811d8c6ff3a505312d3276590444289',1,'pps-client.h']]]
];
