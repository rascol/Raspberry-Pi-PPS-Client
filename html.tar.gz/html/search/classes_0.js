var searchData=
[
  ['g',['G',['../dc/d1d/struct_g.html',1,'']]]
];
