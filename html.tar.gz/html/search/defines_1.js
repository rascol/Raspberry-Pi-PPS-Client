var searchData=
[
  ['block_5ffor_5f10',['BLOCK_FOR_10',['../d4/d6a/pps-client_8h.html#a08849c8fdef5fec756eafb0fdfe687f9',1,'pps-client.h']]],
  ['block_5ffor_5f3',['BLOCK_FOR_3',['../d4/d6a/pps-client_8h.html#a742ea471389308313f44b113dedd5d4e',1,'pps-client.h']]]
];
