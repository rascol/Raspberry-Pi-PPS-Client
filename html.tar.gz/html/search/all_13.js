var searchData=
[
  ['valid_5fconfig',['valid_config',['../d0/d3e/pps-files_8cpp.html#a31b5ef1b0f0166b998ac9136cd6ccb56',1,'pps-files.cpp']]],
  ['version',['version',['../d5/d60/pps-client_8cpp.html#aa31f487a99743d24af9076a3e11e5425',1,'version():&#160;pps-client.cpp'],['../d0/d3e/pps-files_8cpp.html#aa31f487a99743d24af9076a3e11e5425',1,'version():&#160;pps-client.cpp']]]
];
