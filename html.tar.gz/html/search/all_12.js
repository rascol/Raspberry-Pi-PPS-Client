var searchData=
[
  ['updatelog',['updateLog',['../dc/d4f/pps-sntp_8cpp.html#ad78b6046af5bbade4a7fc8941d689f44',1,'pps-sntp.cpp']]],
  ['usecs_5fper_5fsec',['USECS_PER_SEC',['../d4/d6a/pps-client_8h.html#aaf33bd56da23b7654f654d201272537e',1,'pps-client.h']]]
];
