var searchData=
[
  ['five_5fminutes',['FIVE_MINUTES',['../d4/d6a/pps-client_8h.html#ad99448f6c9d49583872a6912f333c90b',1,'pps-client.h']]],
  ['freqdiff_5fintrvl',['FREQDIFF_INTRVL',['../d4/d6a/pps-client_8h.html#a3579917ba71dd1c384ef8aa5078154b6',1,'pps-client.h']]]
];
