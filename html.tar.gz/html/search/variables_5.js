var searchData=
[
  ['g',['g',['../d5/d60/pps-client_8cpp.html#a6fc43fe650a73ed6e4567288c6e1c6bd',1,'g():&#160;pps-client.cpp'],['../d0/d3e/pps-files_8cpp.html#a6fc43fe650a73ed6e4567288c6e1c6bd',1,'g():&#160;pps-client.cpp'],['../df/d28/pps-serial_8cpp.html#a6fc43fe650a73ed6e4567288c6e1c6bd',1,'g():&#160;pps-client.cpp'],['../dc/d4f/pps-sntp_8cpp.html#a6fc43fe650a73ed6e4567288c6e1c6bd',1,'g():&#160;pps-client.cpp']]]
];
