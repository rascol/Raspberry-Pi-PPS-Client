var searchData=
[
  ['max_5fconfigs',['MAX_CONFIGS',['../d4/d6a/pps-client_8h.html#abb4810b7bfb1d61d218e0703daf63e35',1,'pps-client.h']]],
  ['max_5fline_5flen',['MAX_LINE_LEN',['../d4/d6a/pps-client_8h.html#a09a3b394b8602092d58347b791158062',1,'pps-client.h']]],
  ['max_5fservers',['MAX_SERVERS',['../d4/d6a/pps-client_8h.html#aaf8d2ae1c0e1c6413c3a70c4526ace9f',1,'pps-client.h']]],
  ['max_5fspikes',['MAX_SPIKES',['../d4/d6a/pps-client_8h.html#ae832fce01d27cda250e4e82ea1963939',1,'pps-client.h']]],
  ['max_5fvalley_5fratio',['MAX_VALLEY_RATIO',['../d4/d6a/pps-client_8h.html#a8a9a8209e2fa5617be575872f04b53a8',1,'pps-client.h']]],
  ['min_5fpeak_5fratio',['MIN_PEAK_RATIO',['../d4/d6a/pps-client_8h.html#a1cd4b84074ac4bffe3c3156ed3c5a442',1,'pps-client.h']]],
  ['msgbuf_5fsz',['MSGBUF_SZ',['../d4/d6a/pps-client_8h.html#adca1d694b3324493b5557238d74a7c56',1,'pps-client.h']]]
];
