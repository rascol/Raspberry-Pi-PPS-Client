var searchData=
[
  ['usecs_5fper_5fsec',['USECS_PER_SEC',['../d4/d6a/pps-client_8h.html#aaf33bd56da23b7654f654d201272537e',1,'pps-client.h']]]
];
