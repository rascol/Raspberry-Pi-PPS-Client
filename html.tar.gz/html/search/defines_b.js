var searchData=
[
  ['offsetfifo_5flen',['OFFSETFIFO_LEN',['../d4/d6a/pps-client_8h.html#ab87e5698333ae711641014ede87c6f1d',1,'pps-client.h']]],
  ['output_5fgpio',['OUTPUT_GPIO',['../d4/d6a/pps-client_8h.html#a261589721f5a1902f630494d6db3681c',1,'pps-client.h']]]
];
