var searchData=
[
  ['error_5fdistrib',['ERROR_DISTRIB',['../d4/d6a/pps-client_8h.html#a3541554e9b7b46c4a5a8794a5c2ef6d2',1,'pps-client.h']]],
  ['error_5fdistrib_5flen',['ERROR_DISTRIB_LEN',['../d4/d6a/pps-client_8h.html#a32c0d0f48b856555b0976181c7b1dc37',1,'pps-client.h']]],
  ['exit_5flost_5fpps',['EXIT_LOST_PPS',['../d4/d6a/pps-client_8h.html#a60cf28ace31d11a0e6716b7ccdd23781',1,'pps-client.h']]]
];
