var searchData=
[
  ['open_5flogerr',['open_logerr',['../d0/d3e/pps-files_8cpp.html#a94ad6f36dae10e5652ea241b11d2e5c7',1,'pps-files.cpp']]]
];
