var searchData=
[
  ['calibrate',['CALIBRATE',['../d4/d6a/pps-client_8h.html#adacf4c0ec79d1e8779e6bad70ddf1ee9',1,'pps-client.h']]],
  ['check_5ftime',['CHECK_TIME',['../d4/d6a/pps-client_8h.html#ab7908aa07cc0dbc8bb780036c96fac20',1,'pps-client.h']]],
  ['check_5ftime_5fserial',['CHECK_TIME_SERIAL',['../d4/d6a/pps-client_8h.html#a63e3c128dcca06220351eaa65b8edadd',1,'pps-client.h']]],
  ['config_5ffile_5fsz',['CONFIG_FILE_SZ',['../d4/d6a/pps-client_8h.html#ae55fb5c7b7d38a74a43325d536eec5ba',1,'pps-client.h']]]
];
