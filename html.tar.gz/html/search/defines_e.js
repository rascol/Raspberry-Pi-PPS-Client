var searchData=
[
  ['secs_5fper_5f10_5fmin',['SECS_PER_10_MIN',['../d4/d6a/pps-client_8h.html#a0f7b1cb32d5536229e81c4d5820628d4',1,'pps-client.h']]],
  ['secs_5fper_5f5_5fmin',['SECS_PER_5_MIN',['../d4/d6a/pps-client_8h.html#af5e9b0ef0927e0957e7b25ce273c2dae',1,'pps-client.h']]],
  ['secs_5fper_5fday',['SECS_PER_DAY',['../d4/d6a/pps-client_8h.html#ae6bc10904b2b09a717f1fb81cce017de',1,'pps-client.h']]],
  ['secs_5fper_5fhour',['SECS_PER_HOUR',['../d4/d6a/pps-client_8h.html#a11528d10d5838afd2d0ec2f5841167cf',1,'pps-client.h']]],
  ['secs_5fper_5fminute',['SECS_PER_MINUTE',['../d4/d6a/pps-client_8h.html#a8011aad3edacabe7850c23b5725a8f51',1,'pps-client.h']]],
  ['serial',['SERIAL',['../d4/d6a/pps-client_8h.html#aae3f0b4211ba45d265973d40ccbb5fd1',1,'pps-client.h']]],
  ['serial_5fport',['SERIAL_PORT',['../d4/d6a/pps-client_8h.html#ac08f8f916661bb5fc606373bea93d274',1,'pps-client.h']]],
  ['settle_5ftime',['SETTLE_TIME',['../d4/d6a/pps-client_8h.html#a629a8fbfb3eef8f7a89a7cdfdea65ac6',1,'pps-client.h']]],
  ['show_5fintrpt_5fdata_5fintvl',['SHOW_INTRPT_DATA_INTVL',['../d4/d6a/pps-client_8h.html#ad14fb47b24aa6fc3830fd2e274abe900',1,'pps-client.h']]],
  ['slew_5flen',['SLEW_LEN',['../d4/d6a/pps-client_8h.html#aa5447872a297a8e1f7b17b52bc91109c',1,'pps-client.h']]],
  ['slew_5fmax',['SLEW_MAX',['../d4/d6a/pps-client_8h.html#adb1e655efe5a27df3bcf552b1a161922',1,'pps-client.h']]],
  ['sntp',['SNTP',['../d4/d6a/pps-client_8h.html#a8e82d864cd50dd089bdea6cbfb9ad0ec',1,'pps-client.h']]],
  ['sntp_5fmsg_5fsz',['SNTP_MSG_SZ',['../d4/d6a/pps-client_8h.html#aabddd0321669a8542acb6e25b30b4c93',1,'pps-client.h']]],
  ['strbuf_5fsz',['STRBUF_SZ',['../d4/d6a/pps-client_8h.html#addbcc6b274a84e72af8132ab8220c613',1,'pps-client.h']]],
  ['sysdelay_5fdistrib',['SYSDELAY_DISTRIB',['../d4/d6a/pps-client_8h.html#a395db5bac24d5caeef1a0319007201e3',1,'pps-client.h']]]
];
