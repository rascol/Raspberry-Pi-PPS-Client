var searchData=
[
  ['jitter_5fdistrib',['JITTER_DISTRIB',['../d4/d6a/pps-client_8h.html#af7c342a0b065329c74a3184e676beab7',1,'pps-client.h']]],
  ['jitter_5fdistrib_5ffile',['jitter_distrib_file',['../d0/d3e/pps-files_8cpp.html#a3fdd4e099b562b4300e4ff25c263356a',1,'pps-files.cpp']]],
  ['jitter_5fdistrib_5flen',['JITTER_DISTRIB_LEN',['../d4/d6a/pps-client_8h.html#a36148c0fdce6b36a1c00f52aafbd43c2',1,'pps-client.h']]]
];
