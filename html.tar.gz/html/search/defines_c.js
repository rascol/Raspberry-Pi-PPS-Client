var searchData=
[
  ['per_5fminute',['PER_MINUTE',['../d4/d6a/pps-client_8h.html#a70ba17dd155878bfb94ac9c40c1d8635',1,'pps-client.h']]],
  ['per_5fnum_5fintegrals',['PER_NUM_INTEGRALS',['../d4/d6a/pps-client_8h.html#aed046d79ee8f353dc816503a28a3ec2d',1,'pps-client.h']]],
  ['pps_5fgpio',['PPS_GPIO',['../d4/d6a/pps-client_8h.html#a59354e0814b03e123ae201544a82aa04',1,'pps-client.h']]],
  ['pthread_5fstack_5frequired',['PTHREAD_STACK_REQUIRED',['../d4/d6a/pps-client_8h.html#aa89b1724cc83a2bea0b142bc72655491',1,'pps-client.h']]]
];
