var searchData=
[
  ['freqoffset',['freqOffset',['../dc/d1d/struct_g.html#ae59f64b56a6a05c940727e937ce449a0',1,'G']]]
];
