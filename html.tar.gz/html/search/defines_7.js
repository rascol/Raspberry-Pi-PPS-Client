var searchData=
[
  ['jitter_5fdistrib',['JITTER_DISTRIB',['../d4/d6a/pps-client_8h.html#af7c342a0b065329c74a3184e676beab7',1,'pps-client.h']]],
  ['jitter_5fdistrib_5flen',['JITTER_DISTRIB_LEN',['../d4/d6a/pps-client_8h.html#a36148c0fdce6b36a1c00f52aafbd43c2',1,'pps-client.h']]]
];
